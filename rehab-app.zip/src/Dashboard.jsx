import React, { useEffect, useState } from "react"
import { supabase } from "./supabaseClient"

export default function Dashboard({ session }) {
  const [sessions, setSessions] = useState([])

  useEffect(() => {
    fetchSessions()
  }, [])

  async function fetchSessions() {
    const { data, error } = await supabase
      .from("sessions")
      .select("*")
      .eq("created_by", session.user.id)

    if (error) {
      console.error("Error fetching sessions:", error)
    } else {
      setSessions(data)
    }
  }

  return (
    <div style={{ padding: 20 }}>
      <h1>الجلسات الخاصة بك</h1>
      {sessions.map((s) => (
        <div key={s.id} style={{ background: "#fff", margin: "1rem 0", padding: "1rem", borderRadius: 8 }}>
          <h3>{s.title}</h3>
          <p>{s.notes || "بدون ملاحظات"}</p>
          <strong>التقييم:</strong> {s.rating || "—"}
        </div>
      ))}
    </div>
  )
}